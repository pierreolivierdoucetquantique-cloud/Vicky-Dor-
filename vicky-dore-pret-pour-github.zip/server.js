// ============================================================
// Serveur de TEST — Vicky Doré
// Comptes clients + espace admin + réservations + email
// ============================================================
// Démarrage : npm install puis npm start
// ============================================================

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const cookieSession = require('cookie-session');
const Database = require('better-sqlite3');
const { Resend } = require('resend');
const multer = require('multer');

const app = express();
const PORT = process.env.PORT || 3000;

if (!process.env.RESEND_API_KEY) {
  console.warn('\n⚠️  RESEND_API_KEY manquant dans .env — les emails ne seront pas envoyés.\n');
}

const resend = new Resend(process.env.RESEND_API_KEY || 're_placeholder');

// ---------- Base de données SQLite ----------
const db = new Database(path.join(__dirname, 'data', 'vickydore.db'));
db.pragma('journal_mode = WAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    birth_date TEXT,
    city TEXT,
    role TEXT NOT NULL DEFAULT 'client', -- 'client' ou 'admin'
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    service_name TEXT NOT NULL,
    service_price_cents INTEGER NOT NULL,
    booking_date TEXT NOT NULL,       -- format AAAA-MM-JJ
    booking_date_label TEXT NOT NULL, -- format affichable
    booking_time TEXT NOT NULL,
    payment_method TEXT NOT NULL,     -- 'carte' ou 'interac'
    status TEXT NOT NULL DEFAULT 'en_attente', -- en_attente / confirme / annule
    reminder_sent_at TEXT,            -- NULL = rappel pas encore envoyé
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS services (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sort_order INTEGER NOT NULL DEFAULT 0,
    name TEXT NOT NULL,
    duration TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    price_cents INTEGER NOT NULL,
    active INTEGER NOT NULL DEFAULT 1,
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS blocked_emails (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE,
    reason TEXT NOT NULL DEFAULT 'age_minimum_non_respecte',
    blocked_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS password_resets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    token_hash TEXT NOT NULL UNIQUE,
    expires_at TEXT NOT NULL,
    used INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS promo_banner (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    image_path TEXT,
    link_url TEXT NOT NULL DEFAULT 'https://www.tiktok.com/@vickyyydore',
    active INTEGER NOT NULL DEFAULT 1,
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  -- Heures d'ouverture par défaut, une ligne par jour de la semaine (0 = dimanche ... 6 = samedi).
  -- "is_open" = 0 signifie que ce jour est fermé par défaut (ex : dimanche).
  CREATE TABLE IF NOT EXISTS business_hours (
    weekday INTEGER PRIMARY KEY CHECK (weekday BETWEEN 0 AND 6),
    is_open INTEGER NOT NULL DEFAULT 1,
    start_time TEXT NOT NULL DEFAULT '09:00',
    end_time TEXT NOT NULL DEFAULT '17:00',
    slot_duration_minutes INTEGER NOT NULL DEFAULT 30,
    break_start TEXT,
    break_end TEXT,
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  -- Blocages ponctuels créés par Vicky : un jour complet (start_time/end_time
  -- vides) ou une plage d'heures précise sur une date donnée (ex: vacances,
  -- rendez-vous personnel, fermeture exceptionnelle).
  CREATE TABLE IF NOT EXISTS blocked_periods (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    blocked_date TEXT NOT NULL,   -- format AAAA-MM-JJ
    start_time TEXT,              -- NULL = jour complet bloqué
    end_time TEXT,                -- NULL = jour complet bloqué
    reason TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);

// Migration légère : si la base existait déjà avant l'ajout de birth_date,
// on ajoute la colonne sans perdre les données existantes.
const userColumns = db.prepare("PRAGMA table_info(users)").all().map(c => c.name);
if (!userColumns.includes('birth_date')) {
  db.exec('ALTER TABLE users ADD COLUMN birth_date TEXT');
}
if (!userColumns.includes('city')) {
  db.exec('ALTER TABLE users ADD COLUMN city TEXT');
}

const bookingColumns = db.prepare("PRAGMA table_info(bookings)").all().map(c => c.name);
if (!bookingColumns.includes('reminder_sent_at')) {
  db.exec('ALTER TABLE bookings ADD COLUMN reminder_sent_at TEXT');
}

// Initialise la ligne unique de la bannière promo si elle n'existe pas encore.
db.prepare('INSERT OR IGNORE INTO promo_banner (id) VALUES (1)').run();

// ---------- Heures d'ouverture : seed initial (une seule fois) ----------
// Par défaut : ouvert lundi à samedi 9h-17h, fermé le dimanche.
// Reproduit l'ancien comportement codé en dur côté client (isSunday = fermé).
function ensureBusinessHoursSeed() {
  const count = db.prepare('SELECT COUNT(*) as n FROM business_hours').get().n;
  if (count > 0) return;
  const insert = db.prepare(`
    INSERT INTO business_hours (weekday, is_open, start_time, end_time, slot_duration_minutes)
    VALUES (?, ?, ?, ?, ?)
  `);
  for (let weekday = 0; weekday <= 6; weekday++) {
    const isOpen = weekday !== 0; // 0 = dimanche
    insert.run(weekday, isOpen ? 1 : 0, '09:00', '17:00', 30);
  }
  console.log('✦ Heures d\'ouverture par défaut initialisées (fermé le dimanche).');
}
ensureBusinessHoursSeed();

// ---------- Catalogue des services : seed initial (une seule fois) ----------
// Important : la base de données est désormais la source de vérité.
// Ce tableau ne sert qu'à peupler la table "services" la toute première fois
// que le serveur démarre (si la table est vide). Toute modification ultérieure
// se fait via l'espace admin et est enregistrée en base.
const DEFAULT_SERVICES = [
  { name: 'Guidance Express', duration: '30 min', priceCents: 4000, description: "Séance rapide permettant d'obtenir des réponses claires sur une situation précise grâce à la guidance intuitive." },
  { name: 'Guidance Intuitive Personnalisée', duration: '60 min', priceCents: 6000, description: 'Guidance intuitive approfondie incluant tirage de cartes et messages adaptés à votre situation actuelle.' },
  { name: 'Petit Soin Énergétique', duration: '30 min', priceCents: 4000, description: "Soin énergétique ciblé favorisant l'équilibre, l'apaisement et le recentrage." },
  { name: 'Soin Énergétique Complet', duration: '60 min', priceCents: 6000, description: 'Rééquilibrage énergétique complet du corps, du cœur et de l\'esprit.' },
];

function ensureServicesSeed() {
  const count = db.prepare('SELECT COUNT(*) as n FROM services').get().n;
  if (count > 0) return;
  const insert = db.prepare(`
    INSERT INTO services (sort_order, name, duration, description, price_cents, active)
    VALUES (?, ?, ?, ?, ?, 1)
  `);
  DEFAULT_SERVICES.forEach((s, i) => insert.run(i, s.name, s.duration, s.description, s.priceCents));
  console.log(`✦ Catalogue des services initialisé (${DEFAULT_SERVICES.length} services).`);
}
ensureServicesSeed();

function formatPriceLabel(cents) {
  return (cents / 100).toFixed(2).replace('.', ',') + ' $';
}

function publicService(row) {
  return {
    id: row.id,
    name: row.name,
    duration: row.duration,
    description: row.description,
    priceCents: row.price_cents,
    price: formatPriceLabel(row.price_cents),
    active: !!row.active,
  };
}

function getActiveServices() {
  return db.prepare('SELECT * FROM services WHERE active = 1 ORDER BY sort_order ASC, id ASC').all();
}

function getServiceById(id) {
  return db.prepare('SELECT * FROM services WHERE id = ?').get(id);
}

// ---------- Création automatique du compte admin (Vicky) au démarrage ----------
function ensureAdminAccount() {
  const adminEmail = (process.env.ADMIN_EMAIL || 'Vicky_dore@hotmail.com').toLowerCase();
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(adminEmail);
  if (existing) return;

  const password = process.env.ADMIN_PASSWORD || 'changez-moi-123';
  const hash = bcrypt.hashSync(password, 10);
  db.prepare(`INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, 'admin')`)
    .run('Vicky Doré', adminEmail, hash);
  console.log(`✦ Compte admin créé : ${adminEmail} (mot de passe défini dans .env -> ADMIN_PASSWORD)`);
}
ensureAdminAccount();

app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(cookieSession({
  name: 'vickydore_session',
  keys: [process.env.SESSION_SECRET || 'dev-secret-changez-moi'],
  maxAge: 30 * 24 * 60 * 60 * 1000, // 30 jours
}));
app.use(express.static(path.join(__dirname, 'public')));

// ============================================================
// Middlewares d'authentification
// ============================================================
function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: 'Vous devez être connecté.' });
  next();
}

function requireAdmin(req, res, next) {
  if (!req.session.userId || req.session.role !== 'admin') {
    return res.status(403).json({ error: 'Accès réservé à l\'administration.' });
  }
  next();
}

// ---------- Upload d'image pour la bannière publicitaire ----------
const uploadsDir = path.join(__dirname, 'public', 'uploads');
fs.mkdirSync(uploadsDir, { recursive: true });

const promoUploadStorage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase() || '.jpg';
    cb(null, `promo-banner-${Date.now()}${ext}`);
  },
});
const promoUpload = multer({
  storage: promoUploadStorage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5 Mo maximum
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    if (!allowed.includes(file.mimetype)) {
      return cb(new Error('Format non supporté. Utilisez une image JPG, PNG, WEBP ou GIF.'));
    }
    cb(null, true);
  },
});

function publicUser(row) {
  return { id: row.id, name: row.name, email: row.email, role: row.role };
}

// ============================================================
// AUTHENTIFICATION
// ============================================================

// Inscription cliente
app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password, birthDate, city } = req.body;
    if (!name || !email || !password || !birthDate || !city) return res.status(400).json({ error: 'Champs manquants.' });
    if (password.length < 6) return res.status(400).json({ error: 'Le mot de passe doit contenir au moins 6 caractères.' });

    const normalizedEmail = email.trim().toLowerCase();

    // Vérification de la liste noire : un email bloqué reste bloqué définitivement,
    // même si une date de naissance valide est fournie lors d'une nouvelle tentative.
    const blocked = db.prepare('SELECT id FROM blocked_emails WHERE email = ?').get(normalizedEmail);
    if (blocked) {
      return res.status(403).json({ error: 'Cette adresse courriel ne peut pas créer de compte.' });
    }

    // Validation de la date de naissance et de l'âge minimum (18 ans)
    const birth = new Date(birthDate);
    if (Number.isNaN(birth.getTime())) {
      return res.status(400).json({ error: 'Date de naissance invalide.' });
    }
    const today = new Date();
    if (birth > today) {
      return res.status(400).json({ error: 'Date de naissance invalide.' });
    }
    let age = today.getFullYear() - birth.getFullYear();
    const hasNotHadBirthdayThisYear =
      today.getMonth() < birth.getMonth() ||
      (today.getMonth() === birth.getMonth() && today.getDate() < birth.getDate());
    if (hasNotHadBirthdayThisYear) age--;

    if (age < 18) {
      // L'email est bloqué définitivement et Vicky est avertie par courriel.
      try {
        db.prepare('INSERT OR IGNORE INTO blocked_emails (email, reason) VALUES (?, ?)')
          .run(normalizedEmail, 'age_minimum_non_respecte');
      } catch (blockErr) {
        console.error('Erreur lors du blocage de l\'email :', blockErr.message);
      }
      try {
        await sendUnderageAttemptAlert({ email: normalizedEmail, name: name.trim(), birthDate });
      } catch (mailErr) {
        console.error('Erreur lors de l\'envoi de l\'alerte âge minimum :', mailErr.message);
      }
      return res.status(403).json({ error: 'Vous devez avoir au moins 18 ans pour créer un compte.' });
    }

    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(normalizedEmail);
    if (existing) return res.status(409).json({ error: 'Un compte existe déjà avec ce courriel.' });

    const hash = bcrypt.hashSync(password, 10);
    const result = db.prepare(`INSERT INTO users (name, email, password_hash, birth_date, city, role) VALUES (?, ?, ?, ?, ?, 'client')`)
      .run(name.trim(), normalizedEmail, hash, birthDate, city.trim());

    const user = { id: result.lastInsertRowid, name: name.trim(), email: normalizedEmail, role: 'client' };
    req.session.userId = user.id;
    req.session.role = user.role;
    res.json({ user });
  } catch (err) {
    console.error('Erreur register :', err.message);
    res.status(500).json({ error: 'Erreur serveur lors de l\'inscription.' });
  }
});

// ============================================================
// Mot de passe oublié — demande de réinitialisation
// ============================================================
// Vérifie que l'email ET la date de naissance correspondent à un même compte
// (évite d'envoyer un lien suite à une simple faute de frappe sur un email
// qui appartiendrait à quelqu'un d'autre, et limite les doublons de demandes).
app.post('/api/auth/forgot-password', async (req, res) => {
  // Message volontairement identique dans tous les cas de "non trouvé", pour
  // ne jamais révéler si un email existe ou non dans la base.
  const genericResponse = {
    message: 'Si ces informations correspondent à un compte existant, un courriel contenant un lien de réinitialisation vient de vous être envoyé.',
  };
  try {
    const { email, birthDate } = req.body;
    if (!email || !birthDate) return res.status(400).json({ error: 'Champs manquants.' });

    const normalizedEmail = email.trim().toLowerCase();
    const user = db.prepare('SELECT * FROM users WHERE email = ? AND birth_date = ?').get(normalizedEmail, birthDate);

    if (!user) {
      // On répond comme si tout allait bien, sans dire si l'email existe ou si c'est la date qui ne correspond pas.
      return res.json(genericResponse);
    }

    // Invalide les anciens jetons non utilisés pour ce compte, pour éviter
    // d'accumuler des liens valides en doublon.
    db.prepare('UPDATE password_resets SET used = 1 WHERE user_id = ? AND used = 0').run(user.id);

    const rawToken = crypto.randomBytes(32).toString('hex');
    const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000).toISOString(); // valide 1 heure

    db.prepare('INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES (?, ?, ?)')
      .run(user.id, tokenHash, expiresAt);

    try {
      await sendPasswordResetEmail({ name: user.name, email: user.email, rawToken });
    } catch (mailErr) {
      console.error('Erreur lors de l\'envoi du courriel de réinitialisation :', mailErr.message);
    }

    res.json(genericResponse);
  } catch (err) {
    console.error('Erreur forgot-password :', err.message);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

// Confirmation de la réinitialisation : vérifie le jeton et met à jour le mot de passe
app.post('/api/auth/reset-password', (req, res) => {
  try {
    const { token, newPassword } = req.body;
    if (!token || !newPassword) return res.status(400).json({ error: 'Champs manquants.' });
    if (newPassword.length < 6) return res.status(400).json({ error: 'Le mot de passe doit contenir au moins 6 caractères.' });

    const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
    const resetRow = db.prepare('SELECT * FROM password_resets WHERE token_hash = ?').get(tokenHash);

    if (!resetRow || resetRow.used === 1) {
      return res.status(400).json({ error: 'Ce lien de réinitialisation est invalide ou a déjà été utilisé.' });
    }
    if (new Date(resetRow.expires_at) < new Date()) {
      return res.status(400).json({ error: 'Ce lien de réinitialisation a expiré. Veuillez en demander un nouveau.' });
    }

    const hash = bcrypt.hashSync(newPassword, 10);
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hash, resetRow.user_id);
    db.prepare('UPDATE password_resets SET used = 1 WHERE id = ?').run(resetRow.id);

    res.json({ success: true });
  } catch (err) {
    console.error('Erreur reset-password :', err.message);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

// Connexion
app.post('/api/auth/login', (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Champs manquants.' });

    const normalizedEmail = email.trim().toLowerCase();
    const row = db.prepare('SELECT * FROM users WHERE email = ?').get(normalizedEmail);
    if (!row) return res.status(401).json({ error: 'Courriel ou mot de passe incorrect.' });

    const valid = bcrypt.compareSync(password, row.password_hash);
    if (!valid) return res.status(401).json({ error: 'Courriel ou mot de passe incorrect.' });

    req.session.userId = row.id;
    req.session.role = row.role;
    res.json({ user: publicUser(row) });
  } catch (err) {
    console.error('Erreur login :', err.message);
    res.status(500).json({ error: 'Erreur serveur lors de la connexion.' });
  }
});

// Déconnexion
app.post('/api/auth/logout', (req, res) => {
  req.session = null;
  res.json({ success: true });
});

// Qui suis-je ?
app.get('/api/auth/me', (req, res) => {
  if (!req.session.userId) return res.json({ user: null });
  const row = db.prepare('SELECT * FROM users WHERE id = ?').get(req.session.userId);
  if (!row) return res.json({ user: null });
  res.json({ user: publicUser(row) });
});

// ============================================================
// RÉSERVATIONS (côté cliente connectée)
// ============================================================

app.post('/api/bookings', requireAuth, async (req, res) => {
  try {
    const { serviceId, bookingDate, bookingDateLabel, bookingTime } = req.body;
    const serviceRow = getServiceById(serviceId);
    if (!serviceRow || !serviceRow.active) return res.status(400).json({ error: 'Service invalide.' });
    if (!bookingDate || !bookingTime) return res.status(400).json({ error: 'Date ou heure manquante.' });

    // Le prix et le nom du service sont figés au moment de la réservation :
    // toute modification ultérieure du catalogue par l'admin n'affecte pas
    // les réservations déjà enregistrées.
    const service = publicService(serviceRow);

    // Empêche deux clientes de réserver le même créneau
    const conflict = db.prepare(`
      SELECT id FROM bookings WHERE booking_date = ? AND booking_time = ? AND status != 'annule'
    `).get(bookingDate, bookingTime);
    if (conflict) return res.status(409).json({ error: 'Ce créneau vient d\'être réservé par quelqu\'un d\'autre. Choisissez-en un autre.' });

    // Seul le virement Interac est proposé : la réservation reste toujours
    // en attente jusqu'à confirmation manuelle de Vicky dans l'espace admin,
    // une fois le virement reçu.
    const paymentMethod = 'interac';
    const status = 'en_attente';

    const result = db.prepare(`
      INSERT INTO bookings (user_id, service_name, service_price_cents, booking_date, booking_date_label, booking_time, payment_method, status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(req.session.userId, service.name, service.priceCents, bookingDate, bookingDateLabel || bookingDate, bookingTime, paymentMethod, status);

    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.session.userId);

    try {
      await sendConfirmationEmails({
        clientName: user.name,
        clientEmail: user.email,
        service,
        bookingDateLabel: bookingDateLabel || bookingDate,
        bookingTime,
        paymentMethod,
        status,
      });
    } catch (emailErr) {
      console.error('⚠️  Erreur envoi email (réservation tout de même enregistrée) :', emailErr.message);
    }

    res.json({ success: true, bookingId: result.lastInsertRowid, status });
  } catch (err) {
    console.error('Erreur création réservation :', err.message);
    res.status(500).json({ error: 'Erreur serveur lors de la réservation.' });
  }
});

// Liste des réservations de la cliente connectée
app.get('/api/bookings/mine', requireAuth, (req, res) => {
  const rows = db.prepare('SELECT * FROM bookings WHERE user_id = ? ORDER BY booking_date DESC, booking_time DESC')
    .all(req.session.userId);
  res.json(rows);
});

// Annuler une réservation (seulement la sienne, et seulement si future)
app.post('/api/bookings/:id/cancel', requireAuth, (req, res) => {
  const booking = db.prepare('SELECT * FROM bookings WHERE id = ?').get(req.params.id);
  if (!booking) return res.status(404).json({ error: 'Réservation introuvable.' });
  if (booking.user_id !== req.session.userId) return res.status(403).json({ error: 'Cette réservation ne vous appartient pas.' });

  db.prepare(`UPDATE bookings SET status = 'annule' WHERE id = ?`).run(req.params.id);
  res.json({ success: true });
});

// ============================================================
// DISPONIBILITÉS (heures d'ouverture + blocages admin + réservations)
// ============================================================

// Convertit "HH:MM" en minutes depuis minuit, pour comparer facilement des plages.
function timeToMinutes(hhmm) {
  const [h, m] = hhmm.split(':').map(Number);
  return h * 60 + m;
}
function minutesToTime(mins) {
  const h = Math.floor(mins / 60).toString().padStart(2, '0');
  const m = (mins % 60).toString().padStart(2, '0');
  return `${h}:${m}`;
}

function getBusinessHoursForWeekday(weekday) {
  return db.prepare('SELECT * FROM business_hours WHERE weekday = ?').get(weekday);
}

function getBlockedPeriodsForDate(dateStr) {
  return db.prepare('SELECT * FROM blocked_periods WHERE blocked_date = ?').all(dateStr);
}

// Calcule la liste des créneaux disponibles pour une date donnée (AAAA-MM-JJ),
// en combinant : heures d'ouverture par défaut du jour de la semaine,
// blocages ponctuels créés par Vicky (jour complet ou plage précise),
// et réservations déjà existantes (statut différent de "annulé").
function computeAvailableSlots(dateStr) {
  const date = new Date(dateStr + 'T00:00:00');
  if (Number.isNaN(date.getTime())) return [];
  const weekday = date.getDay();

  const hours = getBusinessHoursForWeekday(weekday);
  if (!hours || !hours.is_open) return [];

  const blocks = getBlockedPeriodsForDate(dateStr);
  // Un blocage sans heure de début/fin = jour complet fermé.
  if (blocks.some(b => !b.start_time || !b.end_time)) return [];

  const taken = db.prepare(`
    SELECT booking_time FROM bookings WHERE booking_date = ? AND status != 'annule'
  `).all(dateStr).map(r => r.booking_time);

  const duration = hours.slot_duration_minutes || 30;
  const slots = [];
  for (let t = timeToMinutes(hours.start_time); t + duration <= timeToMinutes(hours.end_time); t += duration) {
    const slotLabel = minutesToTime(t);
    const slotEnd = t + duration;

    // Exclu si dans la pause déjeuner habituelle (s'il y en a une).
    if (hours.break_start && hours.break_end) {
      const breakStart = timeToMinutes(hours.break_start);
      const breakEnd = timeToMinutes(hours.break_end);
      if (t < breakEnd && slotEnd > breakStart) continue;
    }

    // Exclu si dans une plage bloquée ponctuelle.
    const isBlocked = blocks.some(b => {
      const bStart = timeToMinutes(b.start_time);
      const bEnd = timeToMinutes(b.end_time);
      return t < bEnd && slotEnd > bStart;
    });
    if (isBlocked) continue;

    // Exclu si déjà réservé.
    if (taken.includes(slotLabel)) continue;

    slots.push(slotLabel);
  }
  return slots;
}

// Route publique (lecture seule) : permet au calendrier client de savoir
// quels jours de la semaine sont ouverts, pour griser les jours fermés
// sans avoir à interroger /api/availability pour chaque jour affiché.
app.get('/api/business-hours', (req, res) => {
  const rows = db.prepare('SELECT * FROM business_hours ORDER BY weekday ASC').all();
  res.json(rows.map(r => ({
    weekday: r.weekday,
    isOpen: !!r.is_open,
    startTime: r.start_time,
    endTime: r.end_time,
  })));
});

// Route publique : utilisée par l'étape "calendrier" de la réservation.
// Remplace l'ancienne génération de créneaux codée en dur côté client.
app.get('/api/availability', (req, res) => {
  const { date } = req.query;
  if (!date) return res.status(400).json({ error: 'Paramètre date manquant.' });
  res.json({ date, slots: computeAvailableSlots(date) });
});
// Conservée pour compatibilité : créneaux déjà pris pour une date donnée.
// La nouvelle route /api/availability est désormais la source recommandée
// côté client, car elle tient aussi compte des heures d'ouverture et des
// blocages admin, pas seulement des réservations existantes.
app.get('/api/bookings/taken', (req, res) => {
  const { date } = req.query; // format AAAA-MM-JJ
  if (!date) return res.status(400).json({ error: 'Paramètre date manquant.' });
  const rows = db.prepare(`SELECT booking_time FROM bookings WHERE booking_date = ? AND status != 'annule'`).all(date);
  res.json({ takenTimes: rows.map(r => r.booking_time) });
});

// ============================================================
// SERVICES (catalogue public — lu par le site pour afficher les services)
// ============================================================

app.get('/api/services', (req, res) => {
  const rows = getActiveServices();
  res.json(rows.map(publicService));
});

// ============================================================
// ESPACE ADMIN (Vicky voit tout)
// ============================================================

app.get('/api/admin/bookings', requireAdmin, (req, res) => {
  const rows = db.prepare(`
    SELECT bookings.*, users.name as client_name, users.email as client_email
    FROM bookings
    JOIN users ON users.id = bookings.user_id
    ORDER BY booking_date DESC, booking_time DESC
  `).all();
  res.json(rows);
});

app.get('/api/admin/clients', requireAdmin, (req, res) => {
  const rows = db.prepare(`SELECT id, name, email, created_at FROM users WHERE role = 'client' ORDER BY created_at DESC`).all();
  res.json(rows);
});

app.post('/api/admin/bookings/:id/status', requireAdmin, (req, res) => {
  const { status } = req.body;
  if (!['en_attente', 'confirme', 'annule'].includes(status)) return res.status(400).json({ error: 'Statut invalide.' });
  db.prepare(`UPDATE bookings SET status = ? WHERE id = ?`).run(status, req.params.id);
  res.json({ success: true });
});

// ---------- Gestion du catalogue des services (prix + description) ----------

// Liste complète (y compris services désactivés, s'il y en a) pour l'admin
app.get('/api/admin/services', requireAdmin, (req, res) => {
  const rows = db.prepare('SELECT * FROM services ORDER BY sort_order ASC, id ASC').all();
  res.json(rows.map(publicService));
});

// Mise à jour du prix et/ou de la description d'un service.
// Important : ceci ne modifie QUE le catalogue affiché pour les futures
// réservations. Les réservations déjà enregistrées gardent en mémoire le
// nom et le prix tels qu'ils étaient au moment de la réservation
// (colonnes service_name / service_price_cents de la table bookings),
// donc rien ne change rétroactivement pour les rendez-vous déjà pris.
app.put('/api/admin/services/:id', requireAdmin, (req, res) => {
  try {
    const existing = getServiceById(req.params.id);
    if (!existing) return res.status(404).json({ error: 'Service introuvable.' });

    const { name, duration, description, price } = req.body;

    let priceCents = existing.price_cents;
    if (price !== undefined && price !== null && price !== '') {
      const normalized = String(price).replace(',', '.').replace(/[^0-9.]/g, '');
      const parsed = Math.round(parseFloat(normalized) * 100);
      if (!Number.isFinite(parsed) || parsed < 0) {
        return res.status(400).json({ error: 'Prix invalide.' });
      }
      priceCents = parsed;
    }

    const newName = (name !== undefined && name !== null && name.trim() !== '') ? name.trim() : existing.name;
    const newDuration = (duration !== undefined && duration !== null && duration.trim() !== '') ? duration.trim() : existing.duration;
    const newDescription = (description !== undefined && description !== null) ? description.trim() : existing.description;

    db.prepare(`
      UPDATE services SET name = ?, duration = ?, description = ?, price_cents = ?, updated_at = datetime('now')
      WHERE id = ?
    `).run(newName, newDuration, newDescription, priceCents, req.params.id);

    const updated = getServiceById(req.params.id);
    res.json({ success: true, service: publicService(updated) });
  } catch (err) {
    console.error('Erreur mise à jour service :', err.message);
    res.status(500).json({ error: 'Erreur serveur lors de la mise à jour du service.' });
  }
});

// ============================================================
// DISPONIBILITÉS — gestion admin (heures d'ouverture + blocages)
// ============================================================

// Liste des 7 jours avec leurs heures d'ouverture actuelles.
app.get('/api/admin/business-hours', requireAdmin, (req, res) => {
  const rows = db.prepare('SELECT * FROM business_hours ORDER BY weekday ASC').all();
  res.json(rows);
});

// Met à jour les heures d'un jour de la semaine (0 = dimanche ... 6 = samedi).
app.put('/api/admin/business-hours/:weekday', requireAdmin, (req, res) => {
  try {
    const weekday = parseInt(req.params.weekday, 10);
    if (!Number.isInteger(weekday) || weekday < 0 || weekday > 6) {
      return res.status(400).json({ error: 'Jour de la semaine invalide.' });
    }
    const existing = getBusinessHoursForWeekday(weekday);
    if (!existing) return res.status(404).json({ error: 'Jour introuvable.' });

    const { isOpen, startTime, endTime, slotDurationMinutes, breakStart, breakEnd } = req.body;

    const newIsOpen = (isOpen !== undefined) ? (isOpen ? 1 : 0) : existing.is_open;
    const newStart = startTime || existing.start_time;
    const newEnd = endTime || existing.end_time;
    const newDuration = slotDurationMinutes ? parseInt(slotDurationMinutes, 10) : existing.slot_duration_minutes;

    if (timeToMinutes(newStart) >= timeToMinutes(newEnd)) {
      return res.status(400).json({ error: 'L\'heure de début doit précéder l\'heure de fin.' });
    }

    // breakStart/breakEnd : chaîne vide ou null = pas de pause.
    const newBreakStart = (breakStart !== undefined) ? (breakStart || null) : existing.break_start;
    const newBreakEnd = (breakEnd !== undefined) ? (breakEnd || null) : existing.break_end;
    if ((newBreakStart && !newBreakEnd) || (!newBreakStart && newBreakEnd)) {
      return res.status(400).json({ error: 'La pause doit avoir une heure de début ET de fin.' });
    }

    db.prepare(`
      UPDATE business_hours
      SET is_open = ?, start_time = ?, end_time = ?, slot_duration_minutes = ?,
          break_start = ?, break_end = ?, updated_at = datetime('now')
      WHERE weekday = ?
    `).run(newIsOpen, newStart, newEnd, newDuration, newBreakStart, newBreakEnd, weekday);

    res.json({ success: true, businessHours: getBusinessHoursForWeekday(weekday) });
  } catch (err) {
    console.error('Erreur mise à jour heures d\'ouverture :', err.message);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

// Liste des blocages à venir (vacances, fermetures, plages bloquées).
app.get('/api/admin/blocked-periods', requireAdmin, (req, res) => {
  const rows = db.prepare(`
    SELECT * FROM blocked_periods WHERE blocked_date >= date('now') ORDER BY blocked_date ASC, start_time ASC
  `).all();
  res.json(rows);
});

// Crée un blocage : jour complet (startTime/endTime omis) ou plage précise.
app.post('/api/admin/blocked-periods', requireAdmin, (req, res) => {
  try {
    const { blockedDate, startTime, endTime, reason } = req.body;
    if (!blockedDate) return res.status(400).json({ error: 'Date manquante.' });

    if ((startTime && !endTime) || (!startTime && endTime)) {
      return res.status(400).json({ error: 'Indiquez une heure de début ET de fin, ou laissez les deux vides pour bloquer la journée complète.' });
    }
    if (startTime && endTime && timeToMinutes(startTime) >= timeToMinutes(endTime)) {
      return res.status(400).json({ error: 'L\'heure de début doit précéder l\'heure de fin.' });
    }

    const result = db.prepare(`
      INSERT INTO blocked_periods (blocked_date, start_time, end_time, reason)
      VALUES (?, ?, ?, ?)
    `).run(blockedDate, startTime || null, endTime || null, (reason || '').trim());

    res.json({ success: true, id: result.lastInsertRowid });
  } catch (err) {
    console.error('Erreur création blocage :', err.message);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

// Supprime un blocage (Vicky change d'avis / erreur de saisie).
app.delete('/api/admin/blocked-periods/:id', requireAdmin, (req, res) => {
  db.prepare('DELETE FROM blocked_periods WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});



// Accessible à tout le monde : la page d'accueil affiche la bannière si elle existe.
app.get('/api/promo-banner', (req, res) => {
  const row = db.prepare('SELECT * FROM promo_banner WHERE id = 1').get();
  if (!row) return res.json({ active: false, imagePath: null, linkUrl: null });
  res.json({
    active: Boolean(row.active) && Boolean(row.image_path),
    imagePath: row.image_path,
    linkUrl: row.link_url,
  });
});

// Admin seulement : téléverse une nouvelle image pour la bannière.
// L'ancienne image (si elle existe) est supprimée du disque pour ne pas accumuler de fichiers inutiles.
app.post('/api/admin/promo-banner/image', requireAdmin, (req, res) => {
  promoUpload.single('image')(req, res, (err) => {
    if (err) {
      return res.status(400).json({ error: err.message || 'Erreur lors du téléversement.' });
    }
    if (!req.file) {
      return res.status(400).json({ error: 'Aucune image reçue.' });
    }
    try {
      const previous = db.prepare('SELECT image_path FROM promo_banner WHERE id = 1').get();
      const newPath = `/uploads/${req.file.filename}`;

      db.prepare(`
        UPDATE promo_banner SET image_path = ?, active = 1, updated_at = datetime('now') WHERE id = 1
      `).run(newPath);

      if (previous && previous.image_path) {
        const oldFile = path.join(__dirname, 'public', previous.image_path.replace(/^\//, ''));
        fs.unlink(oldFile, () => {}); // suppression silencieuse, sans bloquer la réponse
      }

      res.json({ success: true, imagePath: newPath });
    } catch (dbErr) {
      console.error('Erreur enregistrement bannière promo :', dbErr.message);
      res.status(500).json({ error: 'Erreur serveur lors de l\'enregistrement.' });
    }
  });
});

// Admin seulement : met à jour le lien de destination et/ou active ou désactive la bannière,
// sans nécessiter un nouveau téléversement d'image.
app.put('/api/admin/promo-banner', requireAdmin, (req, res) => {
  try {
    const { linkUrl, active } = req.body;
    const current = db.prepare('SELECT * FROM promo_banner WHERE id = 1').get();

    const newLink = (linkUrl !== undefined && linkUrl !== null && linkUrl.trim() !== '')
      ? linkUrl.trim()
      : current.link_url;
    const newActive = (active !== undefined) ? (active ? 1 : 0) : current.active;

    db.prepare(`
      UPDATE promo_banner SET link_url = ?, active = ?, updated_at = datetime('now') WHERE id = 1
    `).run(newLink, newActive);

    res.json({ success: true });
  } catch (err) {
    console.error('Erreur mise à jour bannière promo :', err.message);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

// Admin seulement : retire complètement l'image actuelle (la bannière redevient masquée).
app.delete('/api/admin/promo-banner/image', requireAdmin, (req, res) => {
  try {
    const current = db.prepare('SELECT image_path FROM promo_banner WHERE id = 1').get();
    if (current && current.image_path) {
      const oldFile = path.join(__dirname, 'public', current.image_path.replace(/^\//, ''));
      fs.unlink(oldFile, () => {});
    }
    db.prepare(`UPDATE promo_banner SET image_path = NULL, active = 0, updated_at = datetime('now') WHERE id = 1`).run();
    res.json({ success: true });
  } catch (err) {
    console.error('Erreur suppression bannière promo :', err.message);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

// ============================================================
// Envoi des emails de confirmation via Resend
// ============================================================
async function sendConfirmationEmails({ clientName, clientEmail, service, bookingDateLabel, bookingTime, paymentMethod, status }) {
  const methodLabel = paymentMethod === 'carte' ? 'Carte bancaire' : 'Virement Interac';
  const statusLabel = status === 'confirme' ? 'Confirmée' : 'En attente de paiement';

  const clientHtml = `
    <div style="font-family:Georgia,serif;color:#352B28;max-width:480px;margin:0 auto;">
      <h2 style="color:#A87C2E;">Votre réservation — ${statusLabel} ✦</h2>
      <p>Bonjour ${escapeHtml(clientName)},</p>
      <table style="width:100%;border-collapse:collapse;margin:16px 0;">
        <tr><td style="padding:6px 0;color:#8A7A74;">Service</td><td style="padding:6px 0;text-align:right;">${escapeHtml(service.name)}</td></tr>
        <tr><td style="padding:6px 0;color:#8A7A74;">Date</td><td style="padding:6px 0;text-align:right;">${escapeHtml(bookingDateLabel)}</td></tr>
        <tr><td style="padding:6px 0;color:#8A7A74;">Heure</td><td style="padding:6px 0;text-align:right;">${escapeHtml(bookingTime)}</td></tr>
        <tr><td style="padding:6px 0;color:#8A7A74;">Paiement</td><td style="padding:6px 0;text-align:right;">${methodLabel}</td></tr>
        <tr><td style="padding:6px 0;color:#8A7A74;font-weight:bold;">Total</td><td style="padding:6px 0;text-align:right;font-weight:bold;">${service.price}</td></tr>
      </table>
      ${paymentMethod === 'interac'
        ? '<p>Merci d\'envoyer votre virement Interac à <strong>Vicky_dore@hotmail.com</strong> pour confirmer votre rendez-vous.</p>'
        : ''}
      <p>Vous pouvez consulter ou annuler ce rendez-vous depuis votre profil sur le site.</p>
      <p>Au plaisir de vous accompagner,<br>Vicky Doré</p>
    </div>
  `;

  const adminHtml = `
    <div style="font-family:Georgia,serif;color:#352B28;">
      <h3>Nouvelle réservation en attente de virement Interac</h3>
      <p><strong>${escapeHtml(clientName)}</strong> (${escapeHtml(clientEmail)})</p>
      <p>${escapeHtml(service.name)} — ${escapeHtml(bookingDateLabel)} à ${escapeHtml(bookingTime)}</p>
      <p>Montant attendu : <strong>${service.price}</strong></p>
      <p>Vérifiez la réception du virement Interac, puis confirmez (ou annulez) cette réservation depuis l'espace admin du site.</p>
    </div>
  `;

  const fromAddress = process.env.EMAIL_FROM || 'onboarding@resend.dev';
  const adminAddress = process.env.ADMIN_EMAIL || 'Vicky_dore@hotmail.com';

  await resend.emails.send({ from: fromAddress, to: clientEmail, subject: 'Votre réservation — Vicky Doré', html: clientHtml });
  await resend.emails.send({ from: fromAddress, to: adminAddress, subject: `Nouvelle réservation : ${service.name}`, html: adminHtml });
}

// ============================================================
// Courriel de rappel — envoyé 24h avant un rendez-vous confirmé
// ============================================================
async function sendReminderEmail({ clientName, clientEmail, serviceName, bookingDateLabel, bookingTime }) {
  const fromAddress = process.env.EMAIL_FROM || 'onboarding@resend.dev';

  const html = `
    <div style="font-family:Georgia,serif;color:#352B28;max-width:480px;margin:0 auto;">
      <h2 style="color:#A87C2E;">Rappel de votre rendez-vous ✦</h2>
      <p>Bonjour ${escapeHtml(clientName)},</p>
      <p>Petit rappel : votre rendez-vous a lieu <strong>demain</strong>.</p>
      <table style="width:100%;border-collapse:collapse;margin:16px 0;">
        <tr><td style="padding:6px 0;color:#8A7A74;">Service</td><td style="padding:6px 0;text-align:right;">${escapeHtml(serviceName)}</td></tr>
        <tr><td style="padding:6px 0;color:#8A7A74;">Date</td><td style="padding:6px 0;text-align:right;">${escapeHtml(bookingDateLabel)}</td></tr>
        <tr><td style="padding:6px 0;color:#8A7A74;">Heure</td><td style="padding:6px 0;text-align:right;">${escapeHtml(bookingTime)}</td></tr>
      </table>
      <p>Si vous devez annuler ou modifier ce rendez-vous, vous pouvez le faire depuis votre profil sur le site, dans « Mes rendez-vous ».</p>
      <p>Au plaisir de vous accompagner,<br>Vicky Doré</p>
    </div>
  `;

  await resend.emails.send({
    from: fromAddress,
    to: clientEmail,
    subject: 'Rappel : votre rendez-vous est demain — Vicky Doré',
    html,
  });
}

// ============================================================
// Alerte admin : tentative d'inscription avec un âge inférieur à 18 ans
// ============================================================
async function sendUnderageAttemptAlert({ email, name, birthDate }) {
  const fromAddress = process.env.EMAIL_FROM || 'onboarding@resend.dev';
  const adminAddress = process.env.ADMIN_EMAIL || 'Vicky_dore@hotmail.com';

  const html = `
    <div style="font-family:Georgia,serif;color:#352B28;">
      <h3 style="color:#B3261E;">⚠️ Tentative d'inscription refusée — âge minimum non respecté</h3>
      <p>Une tentative de création de compte a été automatiquement refusée car la personne a indiqué un âge inférieur à 18 ans.</p>
      <table style="border-collapse:collapse;margin:12px 0;">
        <tr><td style="padding:4px 12px 4px 0;color:#8A7A74;">Nom fourni</td><td style="padding:4px 0;">${escapeHtml(name)}</td></tr>
        <tr><td style="padding:4px 12px 4px 0;color:#8A7A74;">Courriel</td><td style="padding:4px 0;">${escapeHtml(email)}</td></tr>
        <tr><td style="padding:4px 12px 4px 0;color:#8A7A74;">Date de naissance fournie</td><td style="padding:4px 0;">${escapeHtml(birthDate)}</td></tr>
      </table>
      <p>Cette adresse courriel a été bloquée automatiquement et ne pourra plus créer de compte sur le site.</p>
    </div>
  `;

  await resend.emails.send({
    from: fromAddress,
    to: adminAddress,
    subject: `Inscription refusée (âge) — ${email}`,
    html,
  });
}

// ============================================================
// Courriel : lien de réinitialisation du mot de passe
// ============================================================
async function sendPasswordResetEmail({ name, email, rawToken }) {
  const fromAddress = process.env.EMAIL_FROM || 'onboarding@resend.dev';
  // SITE_URL doit être défini dans .env (ex: https://www.vickydore.com). En son
  // absence, on retombe sur localhost pour les tests en local.
  const siteUrl = process.env.SITE_URL || 'http://localhost:3000';
  const resetLink = `${siteUrl}/?reset=${rawToken}`;

  const html = `
    <div style="font-family:Georgia,serif;color:#352B28;max-width:480px;margin:0 auto;">
      <h2 style="color:#A87C2E;">Réinitialisation de votre mot de passe ✦</h2>
      <p>Bonjour ${escapeHtml(name)},</p>
      <p>Une demande de réinitialisation de mot de passe a été faite pour votre compte. Cliquez sur le bouton ci-dessous pour choisir un nouveau mot de passe :</p>
      <p style="text-align:center;margin:28px 0;">
        <a href="${resetLink}" style="background:#A87C2E;color:#fff;padding:12px 28px;border-radius:10px;text-decoration:none;font-family:-apple-system,sans-serif;font-weight:600;display:inline-block;">Réinitialiser mon mot de passe</a>
      </p>
      <p style="font-size:13px;color:#8A7A74;">Ce lien est valide pendant 1 heure. Si vous n'avez pas demandé cette réinitialisation, vous pouvez ignorer ce courriel sans crainte : votre mot de passe actuel reste inchangé.</p>
      <p>Au plaisir de vous accompagner,<br>Vicky Doré</p>
    </div>
  `;

  await resend.emails.send({
    from: fromAddress,
    to: email,
    subject: 'Réinitialisation de votre mot de passe — Vicky Doré',
    html,
  });
}

function escapeHtml(str) {
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// ============================================================
// Rappels automatiques — vérification périodique (toutes les 15 min)
// ============================================================
// Envoie un courriel de rappel aux clientes dont le rendez-vous CONFIRMÉ a
// lieu dans environ 24h. La fenêtre de tolérance (REMINDER_WINDOW_MINUTES)
// existe parce que la vérification ne tourne pas en continu, seulement à
// intervalles réguliers : sans cette marge, un rendez-vous pourrait passer
// entre deux vérifications sans jamais recevoir son rappel.
const REMINDER_CHECK_INTERVAL_MS = 15 * 60 * 1000; // toutes les 15 minutes
const REMINDER_TARGET_HOURS_BEFORE = 24;
const REMINDER_WINDOW_MINUTES = 20; // doit être > à la moitié de l'intervalle ci-dessus

async function checkAndSendReminders() {
  try {
    // Seules les réservations confirmées et pas déjà rappelées sont candidates.
    // On élargit la recherche aux deux derniers jours pour couvrir le passage
    // de minuit, puis on filtre précisément en JS avec la date/heure réelle.
    const candidates = db.prepare(`
      SELECT bookings.*, users.name as client_name, users.email as client_email
      FROM bookings
      JOIN users ON users.id = bookings.user_id
      WHERE bookings.status = 'confirme'
        AND bookings.reminder_sent_at IS NULL
        AND bookings.booking_date >= date('now')
        AND bookings.booking_date <= date('now', '+2 days')
    `).all();

    const now = Date.now();

    for (const booking of candidates) {
      const bookingMoment = new Date(`${booking.booking_date}T${booking.booking_time}:00`);
      if (Number.isNaN(bookingMoment.getTime())) continue;

      const minutesUntilBooking = (bookingMoment.getTime() - now) / (60 * 1000);
      const targetMinutes = REMINDER_TARGET_HOURS_BEFORE * 60;

      // On envoie le rappel dès que le rendez-vous entre dans la fenêtre des
      // 24h (avec une petite marge), et tant qu'il n'est pas encore passé.
      // Cette borne large (plutôt qu'une fenêtre étroite autour de 24h)
      // évite qu'un rappel soit manqué si le serveur était éteint au moment
      // précis où il aurait dû se déclencher (ex : ordinateur fermé la nuit) :
      // au prochain démarrage, le rendez-vous sera toujours détecté et rappelé,
      // pourvu qu'il reste encore à venir.
      const isWithinReminderWindow = minutesUntilBooking > 0 && minutesUntilBooking <= (targetMinutes + REMINDER_WINDOW_MINUTES);
      if (!isWithinReminderWindow) continue;

      try {
        await sendReminderEmail({
          clientName: booking.client_name,
          clientEmail: booking.client_email,
          serviceName: booking.service_name,
          bookingDateLabel: booking.booking_date_label,
          bookingTime: booking.booking_time,
        });
        db.prepare(`UPDATE bookings SET reminder_sent_at = datetime('now') WHERE id = ?`).run(booking.id);
        console.log(`✦ Rappel envoyé pour la réservation #${booking.id} (${booking.client_email})`);
      } catch (mailErr) {
        console.error(`⚠️  Erreur envoi rappel pour la réservation #${booking.id} :`, mailErr.message);
        // Pas de marquage reminder_sent_at en cas d'échec : on retentera à la prochaine vérification.
      }
    }
  } catch (err) {
    console.error('Erreur lors de la vérification des rappels :', err.message);
  }
}

// Premier passage peu après le démarrage (laisse le serveur finir de s'initialiser),
// puis vérification répétée toutes les 15 minutes tant que le serveur tourne.
setTimeout(checkAndSendReminders, 10 * 1000);
setInterval(checkAndSendReminders, REMINDER_CHECK_INTERVAL_MS);

app.listen(PORT, () => {
  console.log(`\n✦ Serveur Vicky Doré (TEST) démarré : http://localhost:${PORT}\n`);
});
